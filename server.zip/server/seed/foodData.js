const foods = [
  {
    name: "Chicken Biryani",
    description: "Hyderabadi style chicken biryani",
    price: 249,
    image: "https://images.unsplash.com/photo-1563379091339-03246963d96c",
    category: "Biryani",
    rating: 4.8,
    available: true,
  },
  {
    name: "Veg Pizza",
    description: "Loaded with fresh vegetables and cheese",
    price: 299,
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591",
    category: "Pizza",
    rating: 4.6,
    available: true,
  },
  {
    name: "Classic Burger",
    description: "Juicy grilled burger with fries",
    price: 199,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd",
    category: "Burger",
    rating: 4.5,
    available: true,
  }
];

export default foods;